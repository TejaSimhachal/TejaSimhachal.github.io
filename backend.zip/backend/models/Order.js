const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
    customerEmail: { type: String, required: true },
    quantity: { type: Number, required: true },
    totalAmount: { type: Number, required: true },
    status: { type: String, enum: ['Pending', 'Accepted', 'Rejected'], default: 'Pending' },
    orderDate: { type: Date, default: Date.now },
    deliveryDate: { type: Date },
    address: { type: String, required: true }
});

module.exports = mongoose.model('Order', orderSchema); 