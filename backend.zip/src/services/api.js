import axios from 'axios';

const API = axios.create({ baseURL: 'http://localhost:5000/api' });

export const fetchTasks = (userId) => API.get(`/tasks/${userId}`);
export const createTask = (task) => API.post('/tasks', task);
export const updateTask = (id, task) => API.put(`/tasks/${id}`, task);
export const deleteTask = (id) => API.delete(`/tasks/${id}`);

export const registerUser = (user) => API.post('/users/register', user);
export const loginUser = (credentials) => API.post('/users/login', credentials);
export const fetchUser = (id) => API.get(`/users/${id}`);
export const updateUser = (id, user) => API.put(`/users/${id}`, user); 